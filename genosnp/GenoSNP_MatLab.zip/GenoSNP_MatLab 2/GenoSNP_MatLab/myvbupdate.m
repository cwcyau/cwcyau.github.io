%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% "GenoSNP: a Variational Bayes within-sample SNP genotyping algorithm
%%% that does not require a reference population", Giannoulatou E., Yau C.
%%% et al, Bioinformatics 2008 Oct 1;24(19):2209-14
%%%
%%%
%%% GenoSNP can be used for academic research purposes only.
%%% For commercial or other use please contact the authors.
%%% Copyright is retained by the University of Oxford.
%%%
%%% Authors:	Eleni Giannoulatou, Christopher Yau
%%% Contact: giannoul@stast.ox.ac.uk
%%%
%%% ©Isis Innovation Ltd 2010
%%%
%%% FUNCTION myvbupdate (called in genoSNP_vb_run)
%%% INPUT
%%% data to be clustered, degrees of freedom, initial cluster centres,
%%% parameters and pior hyperparameters (see genoSNP_vb_run), number of EM
%%% iterations
%%%
%%% OUTPUT
%%% posterior probabilites of each genotype for each SNP in the beadpool
%%%        AA  AB  BB  NC
%%% SNP1
%%% SNP2
%%% ...
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




function post = myvbupdate(x, nu, m_bold, S, kappa, gamma_m, eta, m_bold0, kappa0, eta0, gamma0, S0, EMiters)

M = size(m_bold, 2);
ndim = size(x, 1); % number of dimensions
N = size(x, 2); % number of data points


% preallocate matrices for storing expectations
q       = zeros(N, M);
rho_bar = zeros(N, M);
alpha   = zeros(N, M);
beta    = zeros(N, M);
u_bar   = zeros(N, M);
u_tilde = zeros(N, M);

% do VB-EM
for it = 1 : EMiters
    
    for m = 1 : M
     
        d = x - repmat(m_bold(:, m), [1 N]);
        xx = sum(d.*(inv(S(:, :, m))*d), 1)';

        pi_tilde(m) = exp( psi(kappa(m)) - psi(sum(kappa)) );
        Lambda_tilde(m) = exp( sum( psi( 0.5*(gamma_m(m)+1-[1:ndim]) ) ) + ndim*log(2) - log( det(S(:, :, m)) ) );

        q(:, m) = gamma(ndim + nu(m))/( gamma(nu(m)/2)*(nu(m)*pi)^(ndim/2) )*pi_tilde(m)*sqrt(Lambda_tilde(m)) ...
            * ( 1 + (gamma_m(m)/nu(m))*xx + ndim/(nu(m)*eta(m)) ).^(-(ndim+nu(m))/2);
        
        alpha(:, m) = (ndim + nu(m))/2;
        beta(:, m) = 0.5*gamma_m(m)*xx + ndim/(2*eta(m)) + nu(m)/2;
        u_bar(:, m) = alpha(:, m)./beta(:, m);
        u_tilde(:, m) = exp( psi(alpha(:, m)) - log(beta(:, m)) );
       
        
    end
    
    rho_bar = q./repmat(sum(q, 2), [1 M]);

    
    % VB-M Update
    for m = 1 : M
        
        % calculate sufficient statistics
        omega_bar(m) = (1/N)*sum(rho_bar(:, m).*u_bar(:, m));

        weights = repmat([rho_bar(:, m).*u_bar(:, m)]', [ndim 1]);
        mu_bar(:, m) = (1/(N*omega_bar(m)))*sum( weights.*x, 2 );

        d = x - repmat(mu_bar(:, m), [1 N]);
        Sigma_bar(:, :, m) = (1/(N*omega_bar(m)))*(weights.*d)*d';
  
        pi_bar(m) = (1/N)*sum( rho_bar(:, m) );

        % update parameters
        kappa(m) = N*pi_bar(m) + kappa0;
        
        eta(m) = N*omega_bar(m) + eta0;  
        
        gamma_m(m) = N*pi_bar(m) + gamma0;
        
        if m ~= M
            
            m_bold(:, m) = ( N*omega_bar(m)*mu_bar(:, m) + eta0*m_bold0(:, m) )/eta(m);
            
            S(:, :, m) = (N*omega_bar(m))*Sigma_bar(:, :, m) ...
                + (N*omega_bar(m)*eta0/eta(m))*( mu_bar(:, m) - m_bold0(:, m) )*( mu_bar(:, m) - m_bold0(:, m) )' ...
                + S0;

        end
        


    end
   
        
end

post = rho_bar
w = pi_bar;
m = m_bold;
s = S;
