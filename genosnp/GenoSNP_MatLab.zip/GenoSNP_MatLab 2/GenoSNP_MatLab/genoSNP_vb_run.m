%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% "GenoSNP: a Variational Bayes within-sample SNP genotyping algorithm
%%% that does not require a reference population", Giannoulatou E., Yau C.
%%% et al, Bioinformatics 2008 Oct 1;24(19):2209-14
%%%
%%% GenoSNP can be used for academic research purposes only.
%%% For commercial or other use please contact the authors.
%%% Copyright is retained by the University of Oxford.
%%%
%%% Authors:	Eleni Giannoulatou, Christopher Yau
%%% Contact: giannoul@stast.ox.ac.uk
%%%
%%% ©Isis Innovation Ltd 2010
%%%
%%% FUNCTION genoSNP_vb_run
%%% INPUT
%%% A: character representation of number that corresponds to first input file
%%% B: character representation of number that corresponds to last input file
%%% datadir: name of the directory that contains the input files
%%% outdir : name of the directory that will have the output files
%%%
%%% input file format:
%%% BeadPool_Number rsID Xallele Yallele
%%%
%%% output file format:
%%% rsID BeadPool_Number genotypeCall posteriorProb
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function genoSNP_vb_run(A, B, datadir, outdir)

A = str2num(A);
B = str2num(B);


dircontents = dir(datadir);
ncontents = length(dircontents);

j = 1;
for i = 3 : ncontents

    sampleid{j} = dircontents(i).name;

    j = j + 1;
end
nsamples = j - 1;


for sid = A : B


    % priors
    M = 4;
    ndim = 2;
    m_bold = [9 6; 8 8; 6 9; 6 6]';
    m_bold0 = m_bold;

    % define parameters
    nu = 4*ones(1, M);
    S = repmat(0.1*eye(ndim), [1 1 M]);
    kappa = 100*ones(1, M);
    gamma_m = 5*ones(1, M);
    eta = ones(1, M);

    kappa0  = 1.1;          % dirichlet prior hyperparameter
    eta0    = 1;            % normal prior hyperparameter
    gamma0  = 1;            % Wishart prior hyperparameter
    S0 = 0.1*eye(ndim);     % Wishart prior hyperparameter


    datfile = [ datadir sampleid{sid} ];
    outfile = [ outdir sampleid{sid} ];

    [bpm, rs0, x0, y0] = textread(datfile, '%n %s %n %n');
    
    loc = find(x0 == 0);
    x0(loc) = 1e-3;
    loc = find(y0 == 0);
    y0(loc) = 1e-3;

    fid = fopen(outfile, 'w');

    fprintf(fid,'%s\t%s\t%s\t%s\n', 'rsId', 'bpm', 'Call', 'Call Prob');

    for beadno= 1:max(bpm)
        % EM options
        EMiters = 25;

        % get SNP data
        loc = find( ( x0 > 0 | y0 > 0 ) & ~isnan(x0) & ~isnan(y0) & bpm == beadno );

        n = length(loc);

        rs  = rs0(loc);
        x   = x0(loc);
        y   = y0(loc);

        data = [x y];
        % data = quantilenorm(data);
        x = data(:, 1);
        y = data(:, 2);

        x = log2(x);
        y = log2(y);

        % cluster
        data = [x y];	

        post = myvbupdate(data', nu, m_bold, S, kappa, gamma_m, eta, m_bold0, kappa0, eta0, gamma0, S0, EMiters);


        [mxpost, mxloc] = max(post, [], 2);

        % print
        for i = 1 : length(mxloc)

            switch mxloc(i)

                case 1
                    call = 'AA';

                case 2
                    call = 'AB';

                case 3
                    call = 'BB';

                otherwise
                    call = 'NC';

            end

            beadnostr = sprintf('%d', beadno);
            postval = sprintf('%1.6f', mxpost(i));
            fprintf(fid, '%s\t%s\t%s\t%s\n', rs{i}, beadnostr, call, postval );

        end

    end

    fclose(fid);

end
