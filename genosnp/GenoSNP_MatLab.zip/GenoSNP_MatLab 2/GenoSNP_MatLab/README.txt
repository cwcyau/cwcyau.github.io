=======
GenoSNP
=======

GenoSNP can be used for academic research purposes only.
For commercial or other use please contact the authors.
Copyright is retained by the University of Oxford.

Authors:	Eleni Giannoulatou, Christopher Yau
Contact: giannoul@stast.ox.ac.uk

� Isis Innovation Ltd 2010

SNP genotyping program for the Illumina Infinium SNP genotyping assay.
Description:  "GenoSNP: a Variational Bayes within-sample SNP genotyping algorithm that does not require a reference population", Giannoulatou E., Yau C. et al, Bioinformatics (submitted)

GenoSNP works on Illumina Infinium SNP genotyping raw data. It can be used for genotyping SNPs from HumanHap300Duo and Duo+, HumanHap550, HumanHap550-Duo, HumanHap650Y and Human1M BeadChip data. 

======
USAGE:
======

The user must provide an Input directory. The full path of the directory that contains the input files must be given. Each input file corresponds to a sample and must have four columns with the following (no header):

BeadPool_Number rsID Xallele Yallele

The columns are:
- BeadPool_Number: number of the beadpool the SNP belongs to
- rsID: the rsID of the SNP
- Xallele: the raw intensity of X allele
- Yallele: the raw intensity of Y allele

GenoSNP works by clustering on the log scale of intensities for each beadpool seperately. Therefore the beadpool information in each input file is necessary. The user should also provide the Output directory (full path). The genotyping results for each file (sample) will be stored in this directory. The output has the following format:

rsID BeadPool_Number genotypeCall posteriorProb

The columns are:
- rsID: the rsID of the SNP
- BeadPool_Number: number of the beadpool the SNP belongs to
- genotypeCall: the genotype call of the SNP
- posteriorProb: the prosterior probability of the call

=======
CONTACT
=======

Please address all questions and comments to Eleni Giannoulatou at giannoul@stats.ox.ac.uk

