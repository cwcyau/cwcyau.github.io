## Code for creating cluster plots - 2 - across samples
## 
## input.file : full path to the input file used by genosnp - multiple samples per file
## output.file: full path to the output file produced by genosnp - mutliple samples per file
## snps.file: file that contains the rsIDs of the SNPs of interest
## sample.index: number from 1 to nmax (= the total number of samples in the input/output samples) indicating which sample to point out on the plot
##
## The function creates one plot for each SNP in the snps.file file.
## It plots the XvsY values for one SNP across all the samples  - the XvsY point for a sample indicated by sample.index is shown in blue.
## All the points are coloured by their genotype.
##

genosnp.plot.2.across.samples <- function(input.samples, output.samples, snps.file, sample.index){
	
	# number of fields in the output sample - used to find number of samples
	fields.number <- count.fields("output.samples", sep="\t")
	nsamples <- (fields.number[1] - 3)/4

	samples.input <- read.table("input.samples")
	samples.output <- read.table("output.samples", header=T)

	# find the SNPs we want to check
	snps <- read.table(snps.file)
	no.snps <- dim(snps)[2]
	ind <- match(snps[,1], samples.input[,2])
	
	# for each SNP
	for(i in 1:length(ind)){
	
		# find X, Y values and genotype	
		x <- as.matrix(samples.input[ind[i],seq(3,nsamples*2+2,2)])
		y <- as.matrix(samples.input[ind[i],seq(4,nsamples*2+2,2)])
		
		gen <- samples.output[ind[i],seq(3,fields.number[1]-3,4)]
	
		ind.AA <- which(gen=="AA")
		ind.AB <- which(gen=="AB")
		ind.BB <- which(gen=="BB")
		ind.NC <- which(gen=="NC")

		# plot all samples for each SNP - point out the sample of interest
		# coloured according to genotypes
		png(paste(snps[i,1],"_across.samples.png",sep=""))
		plot(log2(x), log2(y),pch=1, xlab="log(Xraw)", ylab="log(Yraw)", main=list(paste("SNP:", as.character(snps[i,1])),col="blue"))
		points(log2(x[ind.AB]), log2(y[ind.AB]),pch=1,col="red")
		points(log2(x[ind.BB]), log2(y[ind.BB]),pch=1,col="green")
		points(log2(x[ind.NC]), log2(y[ind.NC]),pch=1,col="grey")
		points(log2(x[sample.index]), log2(y[sample.index]),pch=15,col="blue")
		dev.off()

	}

	

}

