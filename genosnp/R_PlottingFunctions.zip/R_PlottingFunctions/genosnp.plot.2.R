## Code for creating cluster plots - 2
## 
## input.file : full path to the input file used by genosnp - multiple samples per file
## output.file: full path to the output file produced by genosnp - mutliple samples per file
## snps.file: file that contains the rsIDs of the SNPs of interest
## sample.index: number from 1 to nmax (= the total number of samples in the input/output samples) indicating which sample to plot
##
## The function creates one plot for each SNP in the snps.file file.
## It plots the XvsY values for the all the SNPs in the beadpool that contains the SNP of interest - the XvsY point for this SNP is shown in blue.
## All the points are coloured by their genotype.
##

genosnp.plot.2 <- function(input.samples, output.samples, snps.file, sample.index){

	# number of fields in the output sample - used for finding the number of samples
	fields.number <- count.fields("output.samples", sep="\t")
	nsamples <- (fields.number[1] - 3)/4
	
	# create vectors used for reading only one sample determined by sample.index
	data.vector.input <- list(bp=0,rsIDs="")
	for(i in 1:nsamples){
		
		if(i==sample.index){
			data.vector.input <- c(data.vector.input, X=0,Y=0)	
		}else{
			data.vector.input <- c(data.vector.input, rep(list(NULL),2))
		}
	}
	
	data.vector.output <- list(rsIDs=" ",bp=0)
	for(i in 1:nsamples){
		
		if(i==sample.index){
			data.vector.output <- c(data.vector.output, gen="", rep(list(NULL),3))	
		}else{
			data.vector.output <- c(data.vector.output, rep(list(NULL),4))
		}
	}
	
	samples.input <- scan("input.samples", what = data.vector.input, skip=0)
	samples.output <- scan("output.samples", what = data.vector.output, skip=1)
	
	# find the SNPs we want to check
	snps <- read.table(snps.file)
	no.snps <- dim(snps)[2]
	ind <- match(snps[,1], samples.input$rsIDs)
	
	# beapool numbers for these SNPs
	beadpools <- samples.input$bp[ind]

	# for each SNP
	for(i in 1:length(beadpools)){
	
		# find all SNPs in the same beadpool
		ind.input.bp <- which(samples.input$bp==beadpools[i])
		ind.output.bp <- which(samples.output$bp==beadpools[i])

		sample.input.rsIDs <- samples.input$rsIDs[ind.input.bp]
		sample.input.x <- samples.input$X[ind.input.bp]
		sample.input.y <- samples.input$Y[ind.input.bp]
		sample.output.gen <- samples.output$gen[ind.output.bp]
		

		ind.AA <- which(sample.output.gen=="AA")
		ind.AB <- which(sample.output.gen=="AB")
		ind.BB <- which(sample.output.gen=="BB")
		ind.NC <- which(sample.output.gen=="NC")
		
		# find the SNP of interest		
		ind.snp <- which(sample.input.rsIDs==as.character(snps[i,1]))

		# for sample sample.index xplot all SNPs in the same beadpool and point out the SNP of interest in blue
		# colour according to genotypes
		png(paste(snps[i,1],"_Sample", sample.index,".png",sep=""))
		plot(log2(sample.input.x), log2(sample.input.y),pch=1, xlab="log(Xraw)", ylab="log(Yraw)", main=list(paste("BeadPool:",beadpools[i], ",", "SNP:", as.character(snps[i,1])),col="blue"))
		points(log2(sample.input.x[ind.AB]), log2(sample.input.y[ind.AB]),pch=1,col="red")
		points(log2(sample.input.x[ind.BB]), log2(sample.input.y[ind.BB]),pch=1,col="green")
		points(log2(sample.input.x[ind.NC]), log2(sample.input.y[ind.NC]),pch=1,col="grey")
		points(log2(sample.input.x[ind.snp]), log2(sample.input.y[ind.snp]),pch=15, col="blue")
		dev.off()

	}
	

}

