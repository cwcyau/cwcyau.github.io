=======================================================
Input/Output Data Formats
=======================================================

One Sample per file:

Each input file corresponds to a sample and must have four columns with the following (no header):

BeadPool_Number rsID Xallele Yallele

The columns are:
- BeadPool_Number: number of the beadpool the SNP belongs to
- rsID: the rsID of the SNP
- Xallele: the raw intensity of X allele
- Yallele: the raw intensity of Y allele

The output has the following format:

rsID BeadPool_Number genotypeCall posteriorProb

The columns are:
- rsID: the rsID of the SNP
- BeadPool_Number: number of the beadpool the SNP belongs to
- genotypeCall: the genotype call of the SNP
- posteriorProb: the prosterior probability of the call

=======================================================

Multiple Samples per file:

There is one Input file that contains all the samples:

BeadPool_Number rsID Xallele(sample1) Yallele(sample1) Xallele(sample2) Yallelle(sample2)�..

So the output has the following format:

rsID BeadPool_Number genotypeCall(sample1) posteriorProbAA(sample1) posteriorProbAB(sample1) posteriorProbBB(sample1) posteriorProbAA(sample2) posteriorProbAB(sample2) posteriorProbBB(sample2) ...

=======================================================


genosnp.plot

This function can be used to analyse results when the format for one sample per file is used. It takes three arguments:
 -  input.file : full path to the input file used by genosnp - one sample per file
 -  output.file: full path to the output file produced by genosnp - one sample per file
 -  snps.file: text file that contains in a column the rsIDs of the SNPs you want to check their genotype
The function creates one plot for each SNP in the snps.file for the sample specified by the input/output files. It plots the XvsY values for the all the SNPs in the beadpool that contains the SNP of interest - the XvsY point for this SNP is shown in a blue rectangle. All the points are coloured by their genotype.

genosnp.plot.2

This function can be used to analyse results when the format for multiple samples per file is used. It takes three arguments:
 -  input.file : full path to the input file used by genosnp - multiple samples per file
 -  output.file: full path to the output file produced by genosnp - multiple samples per file
 -  snps.file: text file that contains in a column the rsIDs of the SNPs you want to check their genotype
 -  sample.index: number from 1 to nmax (= the total number of samples in the input/output samples) indicating which sample to plot
The function also creates one plot for each SNP in the snps.file for the sample specified by sample.index. It plots the XvsY values for the all the SNPs in the beadpool that contains the SNP of interest - the XvsY point for this SNP is shown in a blue rectangle. All the points are coloured by their genotype. 

genosnp.plot.2.across.samples

The plots created by this function do not show the space where genoSNP calls; they show the raw values for one SNP across samples. This is to be used only to compare a within-sample approach to a within-SNP approach for a SNP under investigation. The colours of the genotypes in the plot show the genotypes given by genoSNP. This is a way to check if an across-samples within-SNP approach would work better for this SNP.
The function takes four arguments:
 - input.file : full path to the input file used by genosnp - multiple samples per file
 -  output.file: full path to the output file produced by genosnp - mutliple samples per file
 -  snps.file: file that contains the rsIDs of the SNPs of interest
 -  sample.index: number from 1 to nmax (= the total number of samples in the input/output samples) indicating which sample to point out (as a blue rectangle) on the plot
The function creates one plot for each SNP in the snps.file. It plots the XvsY values for one SNP across all the samples. The XvsY point for a sample indicated by sample.index is shown in blue.

The last function might not prove useful (for plotting across samples) if you have very big files of thousands of samples per file as it loads all the input/output files into memory. Another useful tool for creating cluster plots (SNP plots across samples) is evoker written by Jeff Barrett:
http://sourceforge.net/projects/evoker/
