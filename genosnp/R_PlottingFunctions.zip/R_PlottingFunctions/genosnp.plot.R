## Code for creating cluster plots
## 
## input.file : full path to the input file used by genosnp - one sample per file
## output.file: full path to the output file produced by genosnp - one sample per file
## snps.file: file that contains the rsIDs of the SNPs of interest
##
## The function creates one plot for each SNP in the snps.file file.
## It plots the XvsY values for the all the SNPs in the beadpool that contains the SNP of interest - the XvsY point for this SNP is shown in blue.
## All the points are coloured by their genotype.
##

genosnp.plot <- function(input.file, output.file, snps.file){

	sample.input <- read.table(input.file)
	sample.output <- read.table(output.file, header=T)

	# find the SNPs we want to check
	snps <- read.table(snps.file)
	no.snps <- dim(snps)[2]
	ind <- match(snps[,1], sample.input[,2])
	
	# beapool numbers for these SNPs
	beadpools <- sample.input[ind,1]
	
	# for each SNP
	for(i in 1:length(beadpools)){
	
		# find all SNPs in the same beadpool
		ind.input.bp <- which(sample.input[,1]==beadpools[i])
		ind.output.bp <- which(sample.output[,2]==beadpools[i])

		sample.input.bp <- sample.input[ind.input.bp,]
		sample.output.bp <- sample.output[ind.output.bp,]

		ind.AA <- which(sample.output.bp[,3]=="AA")
		ind.AB <- which(sample.output.bp[,3]=="AB")
		ind.BB <- which(sample.output.bp[,3]=="BB")
		ind.NC <- which(sample.output.bp[,3]=="NC")

		# find the SNP of interest		
		ind.snp <- which(sample.output.bp[,1]==as.character(snps[i,1]))

		# plot all SNPs in the same beadpool and point out the SNP of interest in blue
		# colour according to genotypes
		png(paste(snps[i,1],".png",sep=""))
		plot(log2(sample.input.bp[,3]), log2(sample.input.bp[,4]),pch=1, xlab="log(Xraw)", ylab="log(Yraw)", main=list(paste("BeadPool:",beadpools[i], ",", "SNP:", as.character(snps[i,1])),col="blue"))
		points(log2(sample.input.bp[ind.AB,3]), log2(sample.input.bp[ind.AB,4]),pch=1,col="red")
		points(log2(sample.input.bp[ind.BB,3]), log2(sample.input.bp[ind.BB,4]),pch=1,col="green")
		points(log2(sample.input.bp[ind.NC,3]), log2(sample.input.bp[ind.NC,4]),pch=1,col="grey")
		points(log2(sample.input.bp[ind.snp,3]), log2(sample.input.bp[ind.snp,4]),pch=15, col="blue")
		dev.off()

	}

}

