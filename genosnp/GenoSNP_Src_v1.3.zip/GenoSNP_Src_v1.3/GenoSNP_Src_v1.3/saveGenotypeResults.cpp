////////////////////////////////////////////////////////////////////////
// GenoSNP: A Variational Bayes within-sample SNP genotyping algorithm
// that does not require a reference population.
// Giannoulatou E, Yau C, Colella S, Ragoussis J, Holmes CC.
// Bioinformatics. 2008 Oct 1;24(19):2209-14
//
//
// GenoSNP can be used for academic research purposes only.
// For commercial or other use please contact the authors.
// Copyright is retained by the University of Oxford.
//
// Authors:	Eleni Giannoulatou, Christopher Yau
// Contact: giannoul@stast.ox.ac.uk
//
// (c) Isis Innovation Ltd 2010
////////////////////////////////////////////////////////////////////////

#include "GenoSNP.h"

// save genotype results to files
void saveGenotypeResults(vector<string> callsFin,mat resultsProb,vector<string> rsIDsFin,vec bpNoFin, int numberOfSNPs,vec snpsIndices,string sampleName,string familyName,fstream &outf,fstream &outpf, char *probsfile){


	 // re-order results according to snpsfile
	vector<string> rsIDsFin_ordered(numberOfSNPs-1),callsFin_ordered(numberOfSNPs-1);
	mat resultsProb_ordered(numberOfSNPs-1, 3);
	resultsProb_ordered.zeros();
	for(int v=0; v<numberOfSNPs-1; v++){
		rsIDsFin_ordered[snpsIndices[v]] = rsIDsFin[v];
		callsFin_ordered[snpsIndices[v]] = callsFin[v];
		for(int t=0; t<3; t++){ // save all 3 probabilities
			resultsProb_ordered(snpsIndices[v],t) = resultsProb(v,t);
		}

	}

	//write calls
	outf << sampleName << "\t";
	outf << familyName  << "\t";
 	for(int v=0; v<numberOfSNPs-1; v++){
		outf <<  callsFin_ordered[v] << "\t";  
	}
	outf << endl;
	
	//write probs
 	if(probsfile!=NULL){
		outpf << sampleName << "\t";
		outpf << familyName  << "\t";
	}
  	 for(int v=0; v<numberOfSNPs-1; v++){
		for(int t=0; t<3; t++){ // save all 3 probabilities
			outpf <<  resultsProb_ordered(v,t) << " ";  			
		}
		outpf << "\t";			
	}
	outpf << endl;

}

