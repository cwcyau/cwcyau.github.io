/* itpp/config.h.in.  Generated from configure.ac by autoheader.  */


#ifndef CONFIG_H
#define CONFIG_H


/* Define to dummy `main' function (if any) required to link to the Fortran
   libraries. */
#undef F77_DUMMY_MAIN

/* Define if F77 and FC dummy `main' functions are identical. */
#undef FC_DUMMY_MAIN_EQ_F77

/* Define to 1 if you have the `acosh' function. */
#undef HAVE_ACOSH

/* Define to 1 if you have the `asinh' function. */
#undef HAVE_ASINH

/* Define to 1 if you have the `atanh' function. */
#undef HAVE_ATANH

/* Define if you have a BLAS library. */
#undef HAVE_BLAS

/* Define if you have an ACML BLAS library. */
#undef HAVE_BLAS_ACML

/* Define if you have an ATLAS BLAS library. */
#undef HAVE_BLAS_ATLAS

/* Define if you have an MKL BLAS library. */
#undef HAVE_BLAS_MKL

/* Define to 1 if you have the `cbrt' function. */
#undef HAVE_CBRT

/* Define to 1 if you have the <cmath> header file. */
#undef HAVE_CMATH

/* Define to 1 if you have the <complex> header file. */
#undef HAVE_COMPLEX

/* Define to 1 if you have the declaration of `isfinite', and to 0 if you
   don't. */
#undef HAVE_DECL_ISFINITE

/* Define to 1 if you have the declaration of `isinf', and to 0 if you don't.
   */
#undef HAVE_DECL_ISINF

/* Define to 1 if you have the declaration of `isnan', and to 0 if you don't.
   */
#undef HAVE_DECL_ISNAN

/* Define to 1 if you have the declaration of `signgam', and to 0 if you
   don't. */
#undef HAVE_DECL_SIGNGAM

/* Define to 1 if you have the <dlfcn.h> header file. */
#undef HAVE_DLFCN_H

/* Define to 1 if you have the `erf' function. */
#undef HAVE_ERF

/* Define to 1 if you have the `erfc' function. */
#undef HAVE_ERFC

/* Define if the compiler supports extern template */
#undef HAVE_EXTERN_TEMPLATE

/* Define if you have FFT library. */
#undef HAVE_FFT

/* Define if you have FFTW3 library. */
#undef HAVE_FFTW3

/* Define if you have ACML FFT library. */
#undef HAVE_FFT_ACML

/* Define if you have MKL FFT library. */
#undef HAVE_FFT_MKL

/* Define to 1 if you have the `finite' function. */
#undef HAVE_FINITE

/* Define to 1 if you have the `fpclass' function. */
#undef HAVE_FPCLASS

/* Define to 1 if you have the <ieeefp.h> header file. */
#undef HAVE_IEEEFP_H

/* Define to 1 if you have the <inttypes.h> header file. */
#undef HAVE_INTTYPES_H

/* Define to 1 if you have the `isfinite' function. */
#undef HAVE_ISFINITE

/* Define to 1 if you have the `isinf' function. */
#undef HAVE_ISINF

/* Define to 1 if you have the `isnan' function. */
#undef HAVE_ISNAN

/* Define if you have LAPACK library. */
#undef HAVE_LAPACK

/* Define to 1 if you have the `lgamma' function. */
#undef HAVE_LGAMMA

/* Define to 1 if you have the `log1p' function. */
#undef HAVE_LOG1P

/* Define to 1 if you have the `log2' function. */
#undef HAVE_LOG2

/* Define to 1 if you have the <memory.h> header file. */
#undef HAVE_MEMORY_H

/* Define to 1 if you have the `rint' function. */
#undef HAVE_RINT

/* Define to 1 if you have the <stdint.h> header file. */
#undef HAVE_STDINT_H

/* Define to 1 if you have the <stdlib.h> header file. */
#undef HAVE_STDLIB_H

/* Define to 1 if you have the `std::isfinite' function. */
#undef HAVE_STD_ISFINITE

/* Define to 1 if you have the `std::isinf' function. */
#undef HAVE_STD_ISINF

/* Define to 1 if you have the `std::isnan' function. */
#undef HAVE_STD_ISNAN

/* Define to 1 if you have the <strings.h> header file. */
#undef HAVE_STRINGS_H

/* Define to 1 if you have the <string.h> header file. */
#undef HAVE_STRING_H

/* Define to 1 if you have the <sys/stat.h> header file. */
#undef HAVE_SYS_STAT_H

/* Define to 1 if you have the <sys/types.h> header file. */
#undef HAVE_SYS_TYPES_H

/* Define to 1 if you have the `tgamma' function. */
#undef HAVE_TGAMMA

/* Define to 1 if you have the <unistd.h> header file. */
#undef HAVE_UNISTD_H

/* Define to use zdotusub_ Fortran wrapper. */
#undef HAVE_ZDOTUSUB

/* Define to use "void zdotu_()". */
#undef HAVE_ZDOTU_VOID

/* Define if you want exceptions handling */
#undef ITPP_EXCEPTIONS

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#undef LT_OBJDIR

/* Name of package */
#undef PACKAGE

/* Define to the address where bug reports for this package should be sent. */
#undef PACKAGE_BUGREPORT

/* Define to the full name of this package. */
#undef PACKAGE_NAME

/* Define to the full name and version of this package. */
#undef PACKAGE_STRING

/* Define to the one symbol short name of this package. */
#undef PACKAGE_TARNAME

/* Define to the version of this package. */
#undef PACKAGE_VERSION

/* The size of `int', as computed by sizeof. */
#undef SIZEOF_INT

/* The size of `long', as computed by sizeof. */
#undef SIZEOF_LONG

/* The size of `long long', as computed by sizeof. */
#undef SIZEOF_LONG_LONG

/* The size of `short', as computed by sizeof. */
#undef SIZEOF_SHORT

/* The size of `unsigned int', as computed by sizeof. */
#undef SIZEOF_UNSIGNED_INT

/* The size of `unsigned long', as computed by sizeof. */
#undef SIZEOF_UNSIGNED_LONG

/* The size of `unsigned long long', as computed by sizeof. */
#undef SIZEOF_UNSIGNED_LONG_LONG

/* The size of `unsigned short', as computed by sizeof. */
#undef SIZEOF_UNSIGNED_SHORT

/* Define to 1 if you have the ANSI C header files. */
#undef STDC_HEADERS

/* Define to 1 if you can safely include both <sys/time.h> and <time.h>. */
#undef TIME_WITH_SYS_TIME

/* Version number of package */
#undef VERSION


#if defined(HAVE_CMATH)
#  include <cmath>
#endif

/* Solaris uses <ieeefp.h> for declaring isnan() and finite() functions */
#if defined(HAVE_IEEEFP_H)
#  include <ieeefp.h>
#endif

/* Microsoft Visual C++ .NET underscore prefixed functions */
#if defined(_MSC_VER)
#  include <cfloat>
#  define HAVE_FINITE 1
#  define finite(x) _finite(x)
#  define HAVE_ISFINITE 1
#  define isfinite(x) _finite(x)
#  define HAVE_ISNAN 1
#  define isnan(x) _isnan(x)
#  define HAVE_FPCLASS 1
#  define fpclass(x) _fpclass(x)
#  define FP_NINF _FPCLASS_NINF
#  define FP_PINF _FPCLASS_PINF
#  define HAVE_JN 1
#  define jn(a, b) _jn(a, b)
#  define HAVE_YN 1
#  define yn(a, b) _yn(a, b)
#  define HAVE_J0 1
#  define j0(a) _j0(a)
#  define HAVE_J1 1
#  define j1(a) _j1(a)
#endif /* defined(_MSC_VER) */

/* IT++ uses only std::min() and std::max() functions, not macros */
#ifdef min
#  undef min
#endif
#ifdef max
#  undef max
#endif

/* Represent GCC version in a concise form */
#define GCC_VERSION (__GNUC__ * 10000           \
                     + __GNUC_MINOR__ * 100     \
                     + __GNUC_PATCHLEVEL__)

#endif /* #ifndef CONFIG_H */

