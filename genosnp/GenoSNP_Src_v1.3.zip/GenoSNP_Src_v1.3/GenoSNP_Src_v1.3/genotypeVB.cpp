// GenoSNP can be used for academic research purposes only.
// For commercial or other use please contact the authors.
// Copyright is retained by the University of Oxford.
//
// Authors:	Eleni Giannoulatou, Christopher Yau
// Contact: giannoul@stast.ox.ac.uk
//
// (c) Isis Innovation Ltd 2010

#include "psif.h"
#include "GenoSNP.h"

using namespace itpp;


void genotypeVB(mat &post, mat &data, vec &nu, mat &m_bold, Array<mat> &S, vec &kappa, vec &gamma_m, vec &eta, mat &m_bold0, double kappa0, double eta0, double gamma0, mat &S0, int EMiters)
{
	int M = m_bold.cols();
	int ndim = data.rows();
	int N = data.cols();

	vec pi_tilde(M), Lambda_tilde(M), omega_bar(M), pi_bar(M);
	pi_tilde.zeros();
	Lambda_tilde.zeros();
	omega_bar.zeros();
	pi_bar.zeros();
	
	mat q(N,M), alpha(N,M), beta(N,M), u_bar(N,M), u_tilde(N,M), rho_bar(N,M), mu_bar(ndim,M), weights(N,M);
	q.zeros();
	alpha.zeros();
	beta.zeros();
	u_bar.zeros();
	u_tilde.zeros();
	rho_bar.zeros();
	mu_bar.zeros();
	weights.zeros();
	mat Stmp(ndim,ndim), Sinv(ndim,ndim), Stmp_bar(ndim,ndim);
	Stmp.zeros();
	Sinv.zeros();
	Stmp_bar.zeros();
	Array<mat> Sigma_bar(M);

	for(int t=0; t<M; t++){
 		Sigma_bar(t) = "0 0;0 0";
 	}

	for(int i=0; i< EMiters; i++){

		mat mm(ndim,N), d(ndim,N);	// mean and x-mean
		mm.zeros();
		d.zeros();
		vec sumq(N);
		sumq.zeros();
	

		for(int m=0; m<M; m++){

			for(int j=0; j<N; j++){
				for(int t=0; t<ndim; t++){
					mm(t,j) = m_bold(t,m);
				}
			}

			d = data - mm;			


			Stmp = S(m);
			//inverse of 2x2 matrix
			mat stmp1(ndim,ndim);
			stmp1(0,0) = Stmp(1,1);
			stmp1(0,1) = -Stmp(0,1);
			stmp1(1,0) = -Stmp(0,1);
			stmp1(1,1) = Stmp(0,0);

			Sinv = (1/(Stmp(0,0)*Stmp(1,1) - Stmp(0,1)*Stmp(1,0)))*stmp1;

			//(x-m)^T S^{-1} (x-m) 

			mat tmp(ndim,N), x(ndim,N);
			tmp.zeros();
			x.zeros();
			vec xx(N);
			xx.zeros();

			tmp = Sinv*d;

			for(int k=0; k<ndim; k++){
				for (int j=0; j<N; j++){
					x(k,j) = d(k,j)*tmp(k,j);
					xx[j] = xx[j]+x(k,j);
				}
			}
	
			//calculate p_tilde
			double sumkappa=0;
			for(int k=0; k<M; k++){
				sumkappa = sumkappa + kappa[k];
			}


			pi_tilde[m] = exp(psi(kappa[m]) - psi(sumkappa));

			//calculate Lambda_tilde

			double sumgamma=0;
			for(int k=0; k<ndim; k++){
				sumgamma = sumgamma + psi(0.5*(gamma_m[m] + 1 - (k + 1)));
			}
			
			// 2x2 matrix determinant
			double detStmp;
			detStmp = Stmp(0,0)*Stmp(1,1) - Stmp(0,1)*Stmp(1,0);
			
			Lambda_tilde[m] = exp(sumgamma + ndim*log(2) - log(detStmp));
	
			//calculate q, alpha, beta, u_bar, u_tilde

			for(int k=0; k<N; k++){
				q(k,m) = exp(lgamma(ndim+nu[m]))/((exp(lgamma(nu[m]/2)))*(pow(nu[m]*ap::pi(),(ndim/2))))*pi_tilde[m]*sqrt(Lambda_tilde[m])* (pow((1+(gamma_m[m]/nu[m])*xx[k] + ndim/(nu[m]*eta[m])),(-(ndim+nu[m])/2)));
				
				sumq[k] = sumq[k] + q(k,m);
				

				alpha(k,m) = (ndim + nu[m])/2;
				beta(k,m) = 0.5*gamma_m[m]*xx[k] + ndim/(2*eta[m]) + nu[m]/2;
				u_bar(k,m) = alpha(k,m)/beta(k,m);
				u_tilde(k,m) = exp(psi(alpha(k,m)) - log(beta(k,m)));
			}
			

		}

		//update rho_bar
		for(int k=0; k<N; k++){
			for(int m=0; m<M; m++){
				rho_bar(k,m) = q(k,m)/sumq[k];

			}
		}


		//VB-M update
		

		for(int m=0; m<M; m++){
			
			// calculate sufficient statistics
			double sum_rho_u=0;
			for(int k=0; k<N; k++){
				weights(k,m) = rho_bar(k,m)*u_bar(k,m);
				sum_rho_u = sum_rho_u + weights(k,m);
			}

        		omega_bar[m] = sum_rho_u / N;


			vec sum_weights(ndim);
			sum_weights.zeros();
			
			for(int t=0; t<ndim; t++){
				sum_weights[t]=0;
				for(int k=0; k<N; k++){
					sum_weights[t] = sum_weights[t] + weights(k,m)*data(t,k);
				}
				mu_bar(t,m) = (1/(N*omega_bar[m]))*sum_weights[t];
			}

			for(int j=0; j<N; j++){
				for(int t=0; t<ndim; t++){
					mm(t,j) = mu_bar(t,m);
				}
			}

			d = data - mm;

			mat Wtmp(ndim,N);
			Wtmp.zeros();
			mat Wdtmp(ndim,ndim);
			Wdtmp.zeros();
			mat dtrans(N,ndim);
			dtrans.zeros();

			for(int k=0; k<N; k++){
				for(int t=0; t<ndim; t++){
					Wtmp(t,k) = weights(k,m)*d(t,k);
				}
			}
		
			transpose(d,dtrans);
			Wdtmp = Wtmp*dtrans;

			Stmp_bar = (1/(N*omega_bar[m]))*Wdtmp;


			double sum_rho=0;
			for(int k=0; k<N; k++){
				sum_rho = sum_rho + rho_bar(k,m);
			}

			pi_bar[m] = sum_rho/N;

			// update parameters
        	kappa[m] = N*pi_bar[m] + kappa0;
			eta[m] = N*omega_bar[m] + eta0;
			gamma_m[m] = N*pi_bar[m] + gamma0;


			if(m!=M-1){
				
				mat mu_bar_tmp(ndim,1), m_bold0_tmp(ndim,1), mtp(ndim,1), mtrans(1,ndim), mr(ndim,ndim),m1(ndim,ndim),m2(ndim,ndim),m3(ndim,ndim); 
				mu_bar_tmp.zeros();
				m_bold0_tmp.zeros();
				mtp.zeros();
				mtrans.zeros();
				mr.zeros();
				m1.zeros();
				m2.zeros();
				m3.zeros();
				
				
				//update m_bold and S	

				for(int t=0; t<ndim; t++){
					m_bold(t,m) = (N*omega_bar[m]*mu_bar(t,m) + eta0*m_bold0(t,m))/eta[m];
					mu_bar_tmp(t,0) = mu_bar(t,m);
					m_bold0_tmp(t,0) = m_bold0(t,m);
				}
	
			
				mtp = mu_bar_tmp - m_bold0_tmp;
				transpose(mtp,mtrans);
				mr = mtp*mtrans;
				m1 = (N*omega_bar[m])*Stmp_bar;
				m2 = (N*omega_bar[m]*eta0/eta[m])*mr;
				m3 = m1+m2;		

				
				Stmp = m3 + S0;
				
				S(m) = Stmp;
				
				
			}				
		}
		
		
		

	}
	post = rho_bar;
}
