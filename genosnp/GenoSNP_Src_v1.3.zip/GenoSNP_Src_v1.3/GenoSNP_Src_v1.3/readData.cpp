////////////////////////////////////////////////////////////////////////
// GenoSNP: A Variational Bayes within-sample SNP genotyping algorithm
// that does not require a reference population.
// Giannoulatou E, Yau C, Colella S, Ragoussis J, Holmes CC.
// Bioinformatics. 2008 Oct 1;24(19):2209-14
//
//
// GenoSNP can be used for academic research purposes only.
// For commercial or other use please contact the authors.
// Copyright is retained by the University of Oxford.
//
// Authors:	Eleni Giannoulatou, Christopher Yau
// Contact: giannoul@stast.ox.ac.uk
//
// (c) Isis Innovation Ltd 2010
////////////////////////////////////////////////////////////////////////

#include "GenoSNP.h"

// count number of SNPs
int countNumberOfSNPs(char *snpsfile){

	int numberOfSNPs=0;

	ifstream fpSNP(snpsfile);

	// read input vectors
	if(fpSNP.peek()==EOF){
		cout << "File " << snpsfile<< " is empty." << "\n";
		cout << "...now exiting to system..." << "\n";
		exit(1);
	}
	
	string txt;
	// count the number of SNPs
	while (!fpSNP.eof()) {
		getline(fpSNP,txt);
		numberOfSNPs = numberOfSNPs + 1;
	}
	fpSNP.close();
	
	cout << "Number of SNPs = " << numberOfSNPs -1 << endl;
	
	return numberOfSNPs;
}

// count number of samples
int countNumberOfsamples(char *samplesfile){

	int samples=0;

	ifstream fp(samplesfile);

	// read input vectors
	if(fp.peek()==EOF){
		cout << "File " << samplesfile<< " is empty." << "\n";
		cout << "...now exiting to system..." << "\n";
		exit(1);
	}
	string txt;
	// count the number of samples
	while (!fp.eof()) {
		getline(fp,txt);
		samples = samples + 1;
	}
	fp.close();

	cout << "Number of samples = " << samples << endl;

	return samples;
}

// read SNPs file
void readSNPsfile(char *snpsfile,vector<string> &rsIDs,vector<string> &alleleA,vector<string> &alleleB,vec &bpNo){
	
	bpNo.zeros();
	string txt;
	char const delims[] = " \t";
	int j=0;

	ifstream fpSNP(snpsfile);

	while (getline(fpSNP,txt)) {
		vector<char> vecString(txt.begin(), txt.end());
		vecString.push_back('\0');
		char* result = strtok(&vecString[0], delims);

		rsIDs[j] = result;
		result = strtok(0, delims);
		bpNo[j] = atof(result);
		result = strtok(0, delims);
		alleleA[j] = result;
		result = strtok(0, delims);
		alleleB[j] = result;
		result = strtok(0, delims);
		
		j++;
	}
	fpSNP.close();



}

//find unique beadpool numbers
void findBeadPools(vec &bpNo,vec &bpNo_unsorted,int &unqBP){

	bpNo_unsorted = bpNo;
	itpp::sort(bpNo);

	unqBP=0;
	for(int rr=1; rr<bpNo.size(); rr++){
		if(bpNo[unqBP]!=bpNo[rr]){
			bpNo[unqBP+1] = bpNo[rr];
			unqBP++;
		}
	}

}

// read X and Y intensities for each sample
void readXYintensities(string line,int numberOfSNPs, vec &x,vec &y,string &sampleName,string &familyName){
	
	x.zeros();
	y.zeros();

	char const delims[] = " \t";
	vector<char> vecString(line.begin(), line.end());
	vecString.push_back('\0');
	char* result = strtok(&vecString[0], delims);

	sampleName = result;
	result = strtok(0, delims);
	familyName = result;
	result = strtok(0, delims);

	for(int w=0; w<numberOfSNPs-1; w++){
		x[w] = atof(result);
		result = strtok(0, delims);
		y[w] = atof(result);
		result = strtok(0, delims);
	}



}

