////////////////////////////////////////////////////////////////////////
// GenoSNP: A Variational Bayes within-sample SNP genotyping algorithm
// that does not require a reference population.
// Giannoulatou E, Yau C, Colella S, Ragoussis J, Holmes CC.
// Bioinformatics. 2008 Oct 1;24(19):2209-14
//
//
// GenoSNP can be used for academic research purposes only.
// For commercial or other use please contact the authors.
// Copyright is retained by the University of Oxford.
//
// Authors:	Eleni Giannoulatou, Christopher Yau
// Contact: giannoul@stast.ox.ac.uk
//
//
// (c) Isis Innovation Ltd 2010
//
// Description: 
//
// Usage:./GenoSNP -snps snpfile.txt -samples samplefile.txt -cutoff 0.7 -calls calls.txt -probs probabilities.txt
//
// Input parameters. Both SNPs and Samples files are mandatory:
//
// -snps     mandatory SNPs input file
// -samples  mandatory Samples input file
// -cutoff   optional cutoff, defaulting to 0.7 (or whatever you decide)
//
// Output parameters. The user may optionally choose for the raw probabilities to be output.
// -calls    mandatory Calls output file
// -probs    optional Probabilities output file
// 
// Input Files:
//
// SNPs file
// The SNPs input file describes the indexes of columns in the Samples file. It also records the Bead Pool and the Alleles of each SNP.
// A tab-separated file with one SNP per row, and alleles separated by a single space.
// <SNP_ID>[TAB]<BEADSET_ID>[TAB]<ALLELE_1>[SP]<ALLELE_2>
//
//
// Samples file
// The Samples input file is the core data file containing the RawX/RawY values for each Sample. The SNP columns are indexed as per SNPs file. 
// The use of Family ID and Individual ID is a convention from Plink.
// If only Individual ID is required then the user should duplicate the Individual ID for the Family ID.
//
// A tab-separated file with one row per Sample, and the rawX, rawY values separated by a single space.
// <FAMILY_ID>[TAB]<INDIVIDUAL_ID>[TAB]<RAW_X_SNP_1>[SP]<RAW_Y_SNP_1>[TAB]<RAW_X_SNP_2>[SP]<RAW_Y_SNP_2> 
////////////////////////////////////////////////////////////////////////////

#include "GenoSNP.h"

int main(int argc,char *argv[])
{

	//input parameters
	char *in_str, *snpsfile = NULL, *samplesfile = NULL, *callsfile = NULL, *probsfile = NULL, *cutoff=NULL;
  
	for(int i = 0; i < argc; i++){
	if(*argv[i] == '-'){ 
	  in_str = argv[i];	
	  
	  if(strcmp(in_str, "-snps") == 0) snpsfile = argv[i + 1]; // snps file 
	  if(strcmp(in_str, "-samples") == 0) samplesfile = argv[i + 1]; // samples file
	  if(strcmp(in_str, "-cutoff") == 0) cutoff = argv[i + 1]; // optional cutoff
	  if(strcmp(in_str, "-calls") == 0) callsfile = argv[i + 1]; // calls file
	  if(strcmp(in_str, "-probs") == 0) probsfile = argv[i + 1]; // probabilities file
	}
	}
	
	double thres = 0.7; // probability threshold
	if(cutoff!=NULL){
		thres = atof(cutoff);
	}
	
	if(snpsfile == NULL or samplesfile == NULL or callsfile == NULL) {
		cout<< "Correct usage: ./GenoSNP -snps snpfile.txt -samples samplefile.txt -cutoff 0.7 -calls calls.txt -probs probabilities.txt"<< endl;
		cout << "Need to specify a snps file, a samples file and a calls output file" << endl;
		exit(1); 		
	}        
	
	// count number of SNPs + samples
	int numberOfSNPs = countNumberOfSNPs(snpsfile);
	countNumberOfsamples(samplesfile);

	// read SNPs file
	vector<string> rsIDs(numberOfSNPs),alleleA(numberOfSNPs),alleleB(numberOfSNPs);
	vec bpNo(numberOfSNPs-1);
	readSNPsfile(snpsfile, rsIDs, alleleA, alleleB, bpNo);
 
 	//find unique BeadPool numbers
 	vec bpNo_unsorted;
 	int unqBP;
 	findBeadPools(bpNo,bpNo_unsorted, unqBP);
 
	ifstream fpSNP(snpsfile);
	ifstream fp(samplesfile);
	
	mat resultsProb(numberOfSNPs-1,3); // all 3 probabilities for each sample
	resultsProb.zeros();
	vector<string> rsIDsFin(numberOfSNPs-1),callsFin(numberOfSNPs-1);
	vec bpNoFin(numberOfSNPs-1),snpsIndices(numberOfSNPs-1);
	bpNoFin.zeros();
	snpsIndices.zeros();

	int r=0;
 		
	fstream outf(callsfile,fstream::in | fstream::out | fstream::trunc);
	fstream outpf(probsfile,fstream::in | fstream::out | fstream::trunc);
	string line;

	//genotype per sample
	while (getline(fp, line)) // for each sample
	{
			
		cout << "Sample: " << r+1 << endl;
		
		vec x(numberOfSNPs), y(numberOfSNPs);
		string sampleName, familyName;
		readXYintensities(line,numberOfSNPs, x, y, sampleName, familyName);			
		
		r++;
				
 		int count =0;
 		int countSNP = 0;

 		//genotype per beadpool
 		for(int beadno=0; beadno<=unqBP; beadno++){
 
 			// priors
 			int M = 4;
 			int ndim = 2;
			mat m_bold(ndim,M);
			m_bold = "9 8 6 6;6 8 9 6";
 			mat m_bold0 = m_bold;
 
			// parameters
			vec nu(M), kappa(M), gamma_m(M), eta(M);
			nu.zeros();
			kappa.zeros();
			gamma_m.zeros();
			eta.zeros();
 
 			Array<mat> S(M); // array of matrices instead of 3D matrix
 
 			// initialisation
 			for(int t=0; t<M; t++){
 				S(t) = "0.1 0;0 0.1";
 				nu[t] = 4;
 				kappa[t] = 100;
 				gamma_m[t] = 5;
 				eta[t] = 1; 				
 			}
 
			double kappa0  = 1.1;         // dirichlet prior hyperparameter
			double eta0    = 1;           // normal prior hyperparameter
			double gamma0  = 1;           // Wishart prior hyperparameter
 			mat S0(ndim,ndim);	     // Wishart prior hyperparameter
 			S0 = "0.1 0;0 0.1" ;

 
 			// EM options
			int EMiters = 25;

			// account for log2(0)
 			for(int k=0; k< numberOfSNPs-1; k++){
 				if (x[k]== 0){
 					x[k] = 0.001;
 				}
 				if (y[k]== 0){
 					y[k] = 0.001;
 				}
 			}
 
 			// get SNP intensity data per BeadPool
 			vec Xb(numberOfSNPs), Yb(numberOfSNPs);
 			Xb.zeros();
 			Yb.zeros();

 			vector<string> rsIDb, alleleAb, alleleBb;
 			int j=0;
 			int length;
 
 			//data per BeadPool
 			for(int k=0; k< numberOfSNPs-1; k++){
 				if (( x[k] > 0 | y[k] > 0 ) && !std::isnan(x[k]) && !std::isnan(y[k]) && bpNo_unsorted[k] == bpNo[beadno]){
 					Xb[j] = x[k];
 					Yb[j] = y[k];
 					rsIDb.push_back(rsIDs[k]);
					alleleAb.push_back(alleleA[k]);
 					alleleBb.push_back(alleleB[k]);
 					snpsIndices[countSNP] = k;
 				 					
 					countSNP++;
 					j++;
 				}
 			}
 			length = j;
 
			vec Xbp(length), Ybp(length);
			Xbp.zeros();
			Ybp.zeros();
  
			mat data(ndim,length), post(length,M);
			data.zeros();
			post.zeros();

 			for(int k=0; k<length; k++){
 				Xbp[k] = log2(Xb[k]);
 				Ybp[k] = log2(Yb[k]);
  			}

  			data.set_row(0,Xbp);
			data.set_row(1,Ybp);


 			cout << "Genotyping SNPs in Beadpool number " <<  bpNo[beadno] << endl;
 			
			// VB-EM - genotype	
 		 	genotypeVB(post, data, nu, m_bold, S, kappa, gamma_m, eta, m_bold0, kappa0, eta0, gamma0, S0, EMiters);
 	
 
 			// get genotype results
			vec postSNP(M);
			int index;
			postSNP.zeros();
			
			for(int k=0; k<length; k++){
				for(int t=0; t<M; t++){
					postSNP[t] = post(k,t);
				}

		 		max(postSNP, index);
 				string call;
 				switch(index){
 					case 0:
 					call = alleleAb[k] + " " + alleleAb[k];
 					break;
 
 					case 1:
 					call = alleleAb[k] + " " + alleleBb[k];
 					break;
 
 					case 2:
 					call = alleleBb[k] + " " + alleleBb[k];
 					break;
 
 					default:
 					call = "0 0";
 
 				}

	 			rsIDsFin[count] = rsIDb[k];
 				bpNoFin[count] = bpNo[beadno];
  				for(int t=0; t<M-1; t++){ // get all 3 probabilities for a call
  					resultsProb(count,t) = postSNP[t];
  				}

  				if(post(k,index) > thres){
  					callsFin[count] = call;
  					}
  				else{
  					callsFin[count] = "0 0";
  				}
 				count++;
  			}

 		}
  
		//save genotype results to files
		saveGenotypeResults(callsFin,resultsProb, rsIDsFin, bpNoFin, numberOfSNPs,snpsIndices, sampleName, familyName, outf, outpf, probsfile);
  } 
 
 	fp.close();
 	outf.close();
 	outpf.close();
 

	return 0;

}
