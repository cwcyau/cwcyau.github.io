////////////////////////////////////////////////////////////////////////
// GenoSNP: A Variational Bayes within-sample SNP genotyping algorithm
// that does not require a reference population.
// Giannoulatou E, Yau C, Colella S, Ragoussis J, Holmes CC.
// Bioinformatics. 2008 Oct 1;24(19):2209-14
//
// GenoSNP can be used for academic research purposes only.
// For commercial or other use please contact the authors.
// Copyright is retained by the University of Oxford.
//
// Authors:	Eleni Giannoulatou, Christopher Yau
// Contact: giannoul@stast.ox.ac.uk
//
// (c) Isis Innovation Ltd 2010
////////////////////////////////////////////////////////////////////////

#ifndef _GenoSNP_H_
#define _GenoSNP_H_

#include <dirent.h>
#include <vector>

#include "./itpp/base/math/elem_math.h"
#include "./itpp/base/math/log_exp.h"
#include "./itpp/base/math/min_max.h"
#include "./itpp/base/math/misc.h"
#include "./itpp/base/array.h"
#include "./itpp/base/binary.h"
#include "./itpp/base/converters.h"
#include "./itpp/base/factory.h"
#include "./itpp/base/itassert.h"
#include "./itpp/base/mat.h"
#include "./itpp/base/matfunc.h"
#include "./itpp/base/sort.h"
#include "./itpp/base/vec.h"
#include "./itpp/base/copy_vector.h"
#include "./itpp/base/help_functions.h"

#include <sys/types.h>
#include <errno.h>
#include <math.h>
#include <time.h>
#include <fstream>
#include <string>
#include <iostream>

using namespace std;
using namespace itpp;
 

int countNumberOfSNPs(char *snpsfile);
int countNumberOfsamples(char *samplesfile);
void readSNPsfile(char *snpsfile,vector<string> &rsIDs,vector<string> &alleleA,vector<string> &alleleB,vec &bpNo);
void findBeadPools(vec &bpNo,vec &bpNo_unsorted,int &unqBP);
void readXYintensities(string line,int numberOfSNPs, vec &x,vec &y,string &sampleName,string &familyName);
void genotypeVB(mat &post, mat &data, vec &nu, mat &m_bold, Array<mat> &S, vec &kappa, vec &gamma_m, vec &eta, mat &m_bold0, double kappa0, double eta0, double gamma0, mat &S0, int EMiters);
void saveGenotypeResults(vector<string> callsFin,mat resultsProb,vector<string> rsIDsFin,vec bpNoFin, int numberOfSNPs,vec snpsIndices,string sampleName,string familyName, fstream &outf , fstream &outpf, char *probsfile);

#endif
